import React from 'react'

function Intermarksheet(props) {
    let Iengmks = props.Iengmks;
    let Isanmks = props.Isanmks;
    let ImatmksA = props.ImatmksA;
    let ImatmksB = props.ImatmksB;
    let Iphmks = props.Iphmks;
    let Ichmks = props.Ichmks;
    let IphPmks = props.IphPmks;
    let IchPmks = props.IchPmks;
    let playername = props.playername;
    let Itolmarks = props.Itolmarks
    let board = props.board;
   
  return (
    <div>
       <table>
        
        <h4>Marks of {playername}</h4>
        <caption> <h3>{board}</h3>  </caption>
      
        <tr >
          <th>Subject</th>
          <th>Max Marks</th>
          <th>Marks Obtained</th>
          <th>Result</th>
          <th>Remarks</th>
        </tr>
        <tr>
          <th>English</th>
          <td>100</td>
          <td>{Iengmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Sanskrit</th>
          <td>100</td>
          <td>{Isanmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Mathematics A</th>
          <td>75</td>
          <td>{ImatmksA}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Mathematics B</th>
          <td>75</td>
          <td>{ImatmksB}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Physics</th>
          <td>60</td>
          <td>{Iphmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Chemistry</th>
          <td>60</td>
          <td>{Ichmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Physics Practical</th>
          <td>30</td>
          <td>{IphPmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Chemistry Practical</th>
          <td>30</td>
          <td>{IchPmks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th >Total</th>
          <th>530</th>
          <th>{Itolmarks}</th>
          <th>Pass</th>
          <th>Good</th>
        </tr>
      </table>
    </div>
  )
}

export default Intermarksheet
