import React from "react";

 
function Markssheet(props) {
   
    
    let telmarks = props.telmarks;
    let hindimarks = props.hindimarks;
    let engmarks = props.engmarks;
    let mathmarks = props.mathmarks;
    let scimarks = props.scimarks;
    let socmarks = props.socmarks;
    let tolmarks = props.tolmarks;
    let playername = props.playername;
    let board = props.board;
    
  return (
    <div>
      <table>
        
        <h4>Marks of {playername}</h4>
        <caption> <h3>{board}</h3>  </caption>
      
        <tr >
          <th>Subject</th>
          <th>Max Marks</th>
          <th>Marks Obtained</th>
          <th>Result</th>
          <th>Remarks</th>
        </tr>
        <tr>
          <th>Telugu</th>
          <td>100</td>
          <td>{telmarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Hindi</th>
          <td>100</td>
          <td>{hindimarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>English</th>
          <td>100</td>
          <td>{engmarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Maths</th>
          <td>100</td>
          <td>{mathmarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Science</th>
          <td>100</td>
          <td>{scimarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th>Social</th>
          <td>100</td>
          <td>{socmarks}</td>
          <td>Pass</td>
          <td>Good</td>
        </tr>
        <tr>
          <th >Total</th>
          <th>600</th>
          <th>{tolmarks}</th>
          <th>Pass</th>
          <th>Good</th>
        </tr>
      </table>
      <h1></h1>
    </div>
  );
}

export default Markssheet;
