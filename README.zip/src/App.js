import logo from './logo.svg';
import './App.css';
import Markssheet from "./component/Markssheet";
import Intermarksheet from "./component/Intermarksheet";
function App() {
     
 


 
  return (
    <div className="App">
       
      <div className = "cont">
      <Markssheet board = "BOARD OF SECONDARY EDUCATION" playername = "MS Dhoni" telmarks = "92" hindimarks = "88" engmarks = "90" mathmarks = "87" scimarks = "91" socmarks = "94" tolmarks = "542"/>
     <Markssheet  board = "BOARD OF SECONDARY EDUCATION" playername = "Virat Kholi" telmarks = "90" hindimarks = "95" engmarks = "87" mathmarks = "93" scimarks = "97" socmarks = "89" tolmarks = "551"/>
     <Markssheet  board = "BOARD OF SECONDARY EDUCATION" playername = "Rohit Sharma" telmarks = "95" hindimarks = "89" engmarks = "85" mathmarks = "90" scimarks = "92" socmarks = "86" tolmarks = "537"/>
      </div>
      <div className = "cont">
      <Intermarksheet board = "BOARD OF INTERMEDIATE" playername = "MS Dhoni" Iengmks = "89" Isanmks = "88" ImatmksA = "72" ImatmksB = "71" Iphmks = "45" Ichmks = "46" IphPmks = "28" IchPmks = "24" Itolmarks = "463"/>
      <Intermarksheet board = "BOARD OF INTERMEDIATE" playername = "Virat Kholi" Iengmks = "92" Isanmks = "93" ImatmksA = "74" ImatmksB = "75" Iphmks = "56" Ichmks = "57" IphPmks = "26" IchPmks = "28" Itolmarks = "501"/>
      <Intermarksheet board = "BOARD OF INTERMEDIATE" playername = "Rohit Sharma" Iengmks = "88" Isanmks = "78" ImatmksA = "70" ImatmksB = "75" Iphmks = "54" Ichmks = "56" IphPmks = "25" IchPmks = "27" Itolmarks = "473"/>
      </div>
     
  </div> 
  

  );
}

export default App;
